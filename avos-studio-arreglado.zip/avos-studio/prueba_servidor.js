// Prueba integral del servidor AVOS: lo arranca, recorre todos los endpoints y lo apaga.
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const PUERTO = 8201;
const BASE = 'http://localhost:' + PUERTO;
const srv = spawn('node', [path.join(__dirname,'servidor.js')], { env: { ...process.env, PORT: String(PUERTO) } });
let salida = '';
srv.stdout.on('data', d => salida += d);
srv.stderr.on('data', d => salida += d);

const espera = ms => new Promise(r => setTimeout(r, ms));
let ok = 0, mal = 0;
function marca(nombre, bien, detalle) {
  console.log((bien ? '  ✅ ' : '  ❌ ') + nombre.padEnd(46) + (detalle || ''));
  bien ? ok++ : mal++;
}

async function main() {
  await espera(1200);
  console.log('── arrancado ──\n' + salida.trim().split('\n').slice(0, 3).join('\n') + '\n');

  // 1. salud
  let r = await fetch(BASE + '/api/salud'); let s = await r.json();
  marca('GET /api/salud', r.ok && s.ok === true, 'tts=' + s.tts.motor + ' ffmpeg=' + s.ffmpeg + ' gemini=' + s.llm.gemini);

  // 2. estáticos
  for (const [u, min] of [['/', 1000000], ['/todo.html', 1000], ['/imagenes.html', 3000], ['/referencia/sistema-lavos.html', 500000], ['/referencia/tirada-123puff.html', 5000], ['/referencia/avos-mapa.html', 5000]]) {
    const rr = await fetch(BASE + u); const b = await rr.arrayBuffer();
    marca('GET ' + u, rr.ok && b.byteLength > min, rr.status + ' · ' + b.byteLength.toLocaleString('es') + ' b');
  }

  // 3. guardar y cargar el proyecto
  const proy = { id: 'prueba', version: 8, titulo: 'Proyecto de prueba', actualizadoEn: Date.now(),
    escenas: [{ id: 'esc-1', titulo: 'El Escriba', script: 'El plano no tenía olor.', imagen: null, kenBurns: 'acercar', subtitulos: true },
              { id: 'esc-2', titulo: 'El Monje', script: 'La ciudad no está dormida.', imagen: null, kenBurns: 'alejar', subtitulos: true }] };
  r = await fetch(BASE + '/api/data/save/video/proyecto', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(proy) });
  s = await r.json().catch(() => ({}));
  marca('POST /api/data/save/video/proyecto', r.ok && s.ok === true, s.ruta + ' · ' + s.bytes + ' b');

  r = await fetch(BASE + '/api/data/load/video/proyecto'); s = await r.json();
  marca('GET /api/data/load/video/proyecto', r.ok && s.escenas.length === 2, s.escenas.length + ' escenas devueltas');

  r = await fetch(BASE + '/api/data/load/video/proyecto'); 
  const otro = await fetch(BASE + '/api/data/load/no/existe');
  marca('GET /api/data/load/… (inexistente)', otro.status === 404, 'HTTP ' + otro.status);

  // 4. los demás save que usa la base
  for (const [ruta, cuerpo] of [['video/subtitulos', { proyecto: 'prueba', srt: '1\n00:00:00,000 --> 00:00:03,000\nHola' }],
                                ['video/registro', { videos: [{ id: 'v1', titulo: 'x' }] }],
                                ['video/exportaciones', { v1: { base64: 'AAAA', bytes: 3, ts: Date.now() } }],
                                ['aprendizaje/estado', { eventos: [{ tipo: 'prueba', ts: Date.now() }], prefs: {} }]]) {
    const rr = await fetch(BASE + '/api/data/save/' + ruta, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo) });
    const jj = await rr.json().catch(() => ({}));
    marca('POST /api/data/save/' + ruta, rr.ok && jj.ok === true, jj.bytes + ' b');
  }

  // 5. subida de imagen de escena (multipart con campo base64, como hace la base)
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8AAAwAB/AF+p7RLAAAAAElFTkSuQmCC', 'base64');
  const fd = new FormData();
  fd.append('base64', 'data:image/png;base64,' + png.toString('base64'));
  r = await fetch(BASE + '/api/media/escena/esc-1/0', { method: 'POST', body: fd }); s = await r.json().catch(() => ({}));
  marca('POST /api/media/escena/<id>/0', r.ok && s.ok === true, s.ruta || JSON.stringify(s));
  if (s.url) {
    const rb = await fetch(BASE + s.url);
    marca('GET ' + s.url, rb.ok && (await rb.arrayBuffer()).byteLength === png.length, 'HTTP ' + rb.status);
  }

  // 6. subida de vídeo + compilar (sin ffmpeg debe degradar, no reventar)
  const webm = Buffer.alloc(60000, 7);
  r = await fetch(BASE + '/api/media/video/prueba.webm', { method: 'POST', headers: { 'Content-Type': 'video/webm' }, body: webm });
  s = await r.json().catch(() => ({}));
  marca('POST /api/media/video/<nombre>', r.ok && s.bytes === webm.length, s.bytes + ' b guardados');

  r = await fetch(BASE + '/api/compilar?preset=avos-cinema&nombre=prueba', { method: 'POST', headers: { 'Content-Type': 'video/webm' }, body: webm });
  s = await r.json().catch(() => ({}));
  marca('POST /api/compilar (sin ffmpeg)', r.ok && s.ffmpeg === false && !!s.rutaWebm, s.motivo || s.ruta);

  // 7. intento de salirse de la carpeta
  const malo = await fetch(BASE + '/api/data/load/../../servidor');
  marca('protección contra ../', malo.status >= 400, 'HTTP ' + malo.status);

  // 8. TTS (necesita salida a internet; se informa, no se penaliza si no hay red)
  try {
    const rt = await fetch(BASE + '/api/tts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: 'El plano no tenía olor.', voicePreset: 'escriba', voiceCode: 'es-ES-Standard-A', rate: 0.92, pitch: 0.95 }) });
    const bt = Buffer.from(await rt.arrayBuffer());
    if (rt.ok && bt.length > 500) marca('POST /api/tts', true, rt.headers.get('content-type') + ' · ' + bt.length + ' bytes de audio');
    else marca('POST /api/tts', false, 'HTTP ' + rt.status + ' · ' + bt.toString().slice(0, 120));
  } catch (e) { marca('POST /api/tts', false, 'sin red: ' + e.message); }

  // 9. imagen con motor gratuito (necesita salida a internet)
  try {
    const ri = await fetch(BASE + '/api/imagen', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: 'a golden desert mirror under a violet sky', width: 512, height: 288, motor: 'flux' }) });
    const bi = Buffer.from(await ri.arrayBuffer());
    if (ri.ok && bi.length > 2000) marca('POST /api/imagen (flux)', true, ri.headers.get('content-type') + ' · ' + (bi.length / 1024).toFixed(0) + ' KB');
    else marca('POST /api/imagen (flux)', false, 'HTTP ' + ri.status + ' · ' + bi.toString().slice(0, 120));
  } catch (e) { marca('POST /api/imagen (flux)', false, 'sin red: ' + e.message); }

  console.log('\n── resultado: ' + ok + ' correctas, ' + mal + ' fallidas ──');
  srv.kill();
  process.exit(mal ? 1 : 0);
}
main().catch(e => { console.error('ERROR en la prueba:', e); srv.kill(); process.exit(2); });
