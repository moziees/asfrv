#!/usr/bin/env bash
# AVOS · instala Piper (voz en español offline) dentro del proyecto.
#   ./instalar_voz.sh              → voz davefx (63 MB)
#   ./instalar_voz.sh sharvard     → voz sharvard (77 MB)
# No necesita root. No toca nada fuera de esta carpeta.
set -euo pipefail
cd "$(dirname "$0")"

VOZ="${1:-davefx}"
PIPER_URL="https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_linux_x86_64.tar.gz"
BASE_VOZ="https://huggingface.co/rhasspy/piper-voices/resolve/main/es/es_ES/${VOZ}/medium"
ONNX="es_ES-${VOZ}-medium.onnx"

echo "── AVOS · instalación de voz offline ──"

if [ "$(uname -s)" != "Linux" ]; then
  echo "Este guion es para Linux. Sistema detectado: $(uname -s)"; exit 1
fi
if [ "$(uname -m)" != "x86_64" ]; then
  echo "El binario de Piper es para x86_64. Arquitectura detectada: $(uname -m)"; exit 1
fi

# 1) binario de piper
if [ -x piper/piper ]; then
  echo "· piper ya está en piper/piper"
else
  echo "· descargando piper (26 MB)…"
  mkdir -p piper
  curl -fL --retry 3 -o /tmp/piper.tar.gz "$PIPER_URL"
  tar -xzf /tmp/piper.tar.gz -C /tmp
  cp -r /tmp/piper/. piper/ 2>/dev/null || cp -r /tmp/piper/* piper/
  rm -rf /tmp/piper.tar.gz /tmp/piper
  chmod +x piper/piper
  echo "· piper instalado: $(piper/piper --version 2>/dev/null || echo ok)"
fi

# 2) voz en español
mkdir -p voces
if [ -f "voces/$ONNX" ]; then
  echo "· la voz $VOZ ya está descargada"
else
  echo "· descargando la voz $VOZ (media, ~70 MB)…"
  curl -fL --retry 3 -o "voces/$ONNX"       "$BASE_VOZ/$ONNX"
  curl -fL --retry 3 -o "voces/$ONNX.json"  "$BASE_VOZ/$ONNX.json"
fi

# 3) prueba real
echo "· probando la voz…"
printf 'El plano no tenía olor. No tenía temperatura. No tenía grietas.' \
  | piper/piper --model "voces/$ONNX" --output_file pruebas/voz_piper.wav 2>/dev/null
echo "· lista: pruebas/voz_piper.wav ($(du -h pruebas/voz_piper.wav | cut -f1))"

cat <<'EOF'

── hecho ──────────────────────────────────────────────
  Arranca el servidor y compruébalo:

      node servidor.js
      → en /api/salud debe decir  "tts piper: sí"

  El servidor encuentra piper/piper y voces/*.onnx solo, no hace
  falta tocar el PATH ni instalar nada del sistema.
───────────────────────────────────────────────────────
EOF
