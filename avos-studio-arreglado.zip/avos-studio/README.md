# AVOS Studio

La app es **`base/index.html`** — la base recuperada de `Sin título 1.html`, intacta.
Todo lo demás de esta carpeta existe para **rellenar lo que le falta sin sustituir ni
cambiar nada de ella**.

```
base/index.html          la app original, byte a byte (md5 968c3d5468395f774af706e67bd2db18)
                         NUNCA se escribe encima
componentes/*.json       los campos que faltan, un archivo por mazo, todos firmados
construir.js             base/index.html + componentes/  →  public/index.html
verificar.js             demuestra que no se ha tocado nada de lo que ya había
servidor.js              los endpoints que la app llama (voz, imagen, guardado, compilar)
prueba_servidor.js       arranca, recorre 21 casos y se apaga
arrancar.sh              comprueba el entorno y arranca
instalar_voz.sh          Piper + voz española offline, sin root

public/                  lo que se sirve
  index.html             la app construida (generada, no se edita a mano)
  imagenes.html          generador de imágenes para las escenas
  todo.html              índice de todo, con el estado del servidor
  referencia/            Sistema Lavos, Tirada 1·2·3·PUFF y las maquetas avos-*
  libro/                 las 101 historias del PDF, el libro de los 13 de la Luz
                         y las interpretaciones (Ley / Oráculo / El enlace) carta a carta
data_local/  media_local/{video,escenas,compilados}
```

## Arrancar

```bash
./arrancar.sh                 # → http://localhost:8080
PUERTO=9000 ./arrancar.sh
```

`arrancar.sh` te dice qué tienes y qué te falta antes de arrancar.

## Voz

Por orden de preferencia, el servidor usa el primero que encuentre:

| motor | cómo se instala | qué da |
|---|---|---|
| **Piper** | `./instalar_voz.sh` | voz offline, sin internet |
| **edge-tts** | `pip install edge-tts` | **voces neuronales en español, gratis y sin clave** |
| Google no oficial | nada | funciona, pero necesita internet y puede caer |

Tus cuatro presets quedan traducidos a voces neuronales respetando su `rate` y su `pitch`:

```
Voz del Escriba     0.92 / 0.95  →  es-ES-AlvaroNeural  −8%  −5Hz
Voz del Rigor       1.00 / 1.00  →  es-ES-XimenaNeural  +0%  +0Hz
Ambient d'Albaicín  0.88 / 1.05  →  es-ES-ElviraNeural  −12% +2Hz
Voz ASMR Poética    0.80 / 1.10  →  es-MX-DaliaNeural   −20% +4Hz
```

## Vídeo

Dentro de la app: módulo **`cinema` — Estudio de Vídeo · Cinema v8**.

- **textos** → `📋 Texto → escenas` (parte por líneas en blanco; bloques de más de 420 caracteres se cortan por frases)
- **imágenes** → `subir png` en cada escena (png/jpeg/webp) o `Imágenes ya descargadas → escenas` en lote
- **desde el oráculo** → la tirada empuja sus escenas sola al estudio
- **exportar** → `Exportar vídeo` (corte completo), `Exportar por escenas`, `Compilar a mp4 en servidor (ffmpeg)`
- **presets** → `youtube` 1920×1080 mp4 · `web` 1920×1080 webm (el máster de la casa) · `reels`/`stories`/`shorts` 1080×1920 · `feed-ig` 1080×1350 · `x` 1280×720

En Linux el navegador no multiplexa mp4: se graba webm y, si hay **ffmpeg**, el servidor lo
convierte con el preset `avos-cinema` (libx264 crf 19 · aac 192k · `+faststart`).
`sudo apt install ffmpeg`. Sin ffmpeg se entrega webm, que YouTube también acepta.

Al terminar, la exportación devuelve el vídeo **y** el SRT **y** el VTT **y** los capítulos.

## Imágenes

La base no trae ningún generador: las escenas sin imagen pintan una tarjeta animada.
`/api/imagen` añade motores gratuitos sin clave (`flux`, `turbo`, `kontext` vía Pollinations),
y `/imagenes.html` los usa: carga el proyecto, genera una imagen por escena a partir de su
`titulo` + `script`, la guarda en `media_local/escenas/` y escribe la ruta dentro del proyecto.
Al recargar la app, las escenas ya vienen con su imagen. **La base no se modifica para esto.**

## Reglas de esta carpeta

1. `base/index.html` nunca se escribe.
2. **Un campo que ya exista en una carta no se sobrescribe jamás.** `construir.js` mira las
   claves de cada carta y solo añade las que faltan; lleva la cuenta de los que se salta.
3. Todo lo añadido va firmado con `firma:"qwen-completado"`: localizable y borrable de un golpe.
4. `verificar.js` lo **demuestra** comparando los dos AST. Cuatro pruebas: lo que no es una
   carta debe ser byte a byte idéntico · ningún campo original puede cambiar de valor ·
   ninguno puede desaparecer · y las únicas claves nuevas permitidas son `explicacion`,
   `demanda`, `preguntas`, `mantra`, `ritual` y `firma`.

```bash
node construir.js && node verificar.js
```

## Molde de los campos

Medido sobre las 91 cartas completas del Heptacorde, que son la referencia:

| campo | patrón | longitud típica |
|---|---|---|
| `explicacion` | ley declarativa que arranca por artículo (La/El/Las) | ~80 |
| `demanda` | "Te pide…" + concepto nombrado + imperativo concreto | ~131 |
| `preguntas` | **siempre 2**: la 1ª de diagnóstico, la 2ª de compromiso | — |
| `mantra` | 1ª persona, presente, dos cláusulas separadas por ";" | ~66 |
| `ritual` | abre con verbo físico (Toma/Dibuja/Coloca/Escribe…) + detalle sensorial | ~166 |

## Estado

Completados: **Rigor Técnico (13)** y **Zener (5)** → 18 cartas, 108 campos.

Pendientes: Escriba 34 · Ángeles 10 · Rider-Waite mayores 22 · Hilo 44 · 13 de la Luz 21 ·
Gitano 36 · Marsella 22 · I Ching 12 = **201 cartas**.

Apartados, a la espera de confirmación: los **56 arcanos menores** y las **10 cartas 92–101**
del Heptacorde. La propia app declara en sus módulos *"13 mazos · 391 cartas · 31 intérpretes
· 9 tiradas"*, y dentro hay 447 cartas y 10 tiradas: la diferencia son exactamente esos 56.
