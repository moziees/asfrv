#!/usr/bin/env node
/*
 * AVOS · servidor local
 * ---------------------------------------------------------------------------
 * Motor que le falta a la base recuperada. Sin dependencias: solo Node 20+.
 *
 *   node servidor.js            → http://localhost:8080
 *   PORT=9000 node servidor.js  → otro puerto
 *
 * Implementa EXACTAMENTE los endpoints que la base ya llama:
 *   GET  /api/salud
 *   POST /api/tts                          (Piper si está instalado; si no, Google no oficial)
 *   POST /api/compilar?preset=&nombre=     (ffmpeg si está instalado; si no, guarda el webm)
 *   POST /api/media/video/<nombre>
 *   POST /api/media/escena/<id>/<n>
 *   GET  /api/data/load/<ruta>
 *   POST /api/data/save/<ruta>
 *   GET  /api/media/<...>                  (devuelve lo guardado)
 *
 * Y añade lo que la base no trae:
 *   POST /api/imagen                       (motores de imagen IA gratuitos, sin clave)
 *   GET  /api/motores
 *
 * Nada de esto toca tus archivos: la base se sirve tal cual desde public/.
 */
'use strict';
const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const { pipeline } = require('stream/promises');
const os = require('os');

const RAIZ = __dirname;
const PUBLIC = path.join(RAIZ, 'public');
const DATA = path.join(RAIZ, 'data_local');
const MEDIA = path.join(RAIZ, 'media_local');
const PUERTO = Number(process.env.PORT || 8080);

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.gif': 'image/gif', '.svg': 'image/svg+xml', '.webm': 'video/webm', '.mp4': 'video/mp4',
  '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.ogg': 'audio/ogg', '.srt': 'text/plain; charset=utf-8',
};

/* ───────────────────────── utilidades ───────────────────────── */

const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

function bin(cmd) {
  try {
    const r = spawnSync(process.platform === 'win32' ? 'where' : 'which', [cmd], { encoding: 'utf8' });
    return r.status === 0 ? r.stdout.split(/\r?\n/)[0].trim() : null;
  } catch { return null; }
}

const FFMPEG = bin('ffmpeg');
// Piper: primero el del PATH, después uno descargado dentro del proyecto (piper/piper)
const PIPER_LOCAL = path.join(RAIZ, 'piper', 'piper');
const PIPER = bin('piper') || (fs.existsSync(PIPER_LOCAL) ? PIPER_LOCAL : null);
const VOCES_PIPER = path.join(RAIZ, 'voces');
// edge-tts: voces neuronales de Microsoft, gratis y sin clave (pip install edge-tts)
const EDGE = bin('edge-tts');

// Los 4 presets de la base (hr) traducidos a voces neuronales, respetando su rate y pitch
const VOCES_EDGE = {
  escriba:  { voz: 'es-ES-AlvaroNeural', rate: '-8%',  pitch: '-5Hz' },  // 0.92 / 0.95
  rigor:    { voz: 'es-ES-XimenaNeural', rate: '+0%',  pitch: '+0Hz' },  // 1.00 / 1.00
  albaicin: { voz: 'es-ES-ElviraNeural', rate: '-12%', pitch: '+2Hz' },  // 0.88 / 1.05
  susurro:  { voz: 'es-MX-DaliaNeural',  rate: '-20%', pitch: '+4Hz' },  // 0.80 / 1.10
};
function vozEdge(preset, voiceCode) {
  const p = VOCES_EDGE[preset] || VOCES_EDGE.escriba;
  // si el cliente manda un voiceCode de Edge directo, se respeta
  const voz = /^es-[A-Z]{2}-\w+Neural$/.test(voiceCode || '') ? voiceCode : p.voz;
  return { voz, rate: p.rate, pitch: p.pitch };
}
function modeloPiper(voiceCode) {
  if (!PIPER) return null;
  try {
    const on = fs.readdirSync(VOCES_PIPER).filter(f => f.endsWith('.onnx'));
    if (!on.length) return null;
    // es-ES-Standard-A → es_ES-*.onnx ; si no hay coincidencia, la primera disponible
    const pref = String(voiceCode || '').slice(0, 2).toLowerCase();
    return path.join(VOCES_PIPER, on.find(f => f.toLowerCase().startsWith(pref)) || on[0]);
  } catch { return null; }
}

function enviar(res, codigo, tipo, cuerpo) {
  res.writeHead(codigo, { 'Content-Type': tipo, 'Cache-Control': 'no-store' });
  res.end(cuerpo);
}
const json = (res, codigo, o) => enviar(res, codigo, 'application/json; charset=utf-8', JSON.stringify(o));

async function leerJSON(req, limite = 8 * 1024 * 1024) {
  const b = await leerBuffer(req, limite);
  try { return JSON.parse(b.toString('utf8')); } catch { return {}; }
}
function leerBuffer(req, limite) {
  return new Promise((ok, ko) => {
    const trozos = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > limite) { ko(new Error('cuerpo demasiado grande')); req.destroy(); } else trozos.push(c); });
    req.on('end', () => ok(Buffer.concat(trozos)));
    req.on('error', ko);
  });
}
// vuelca el cuerpo de la petición directamente a disco (sin meterlo en memoria)
async function volcarA(req, archivo, limite = 4 * 1024 * 1024 * 1024) {
  await fsp.mkdir(path.dirname(archivo), { recursive: true });
  let n = 0;
  const out = fs.createWriteStream(archivo);
  await pipeline(req, out);
  n = (await fsp.stat(archivo)).size;
  if (n > limite) { await fsp.unlink(archivo).catch(() => {}); throw new Error('archivo demasiado grande'); }
  return n;
}
// evita salirse de la carpeta con ../
function seguro(base, relativo) {
  const p = path.resolve(base, '.' + path.posix.normalize('/' + relativo));
  if (!p.startsWith(base)) throw new Error('ruta no permitida');
  return p;
}
function trocea(texto, max = 199) {
  const t = String(texto || '').replace(/\s+/g, ' ').trim();
  if (t.length <= max) return [t];
  const out = []; let resto = t;
  while (resto.length > max) {
    let corte = resto.lastIndexOf(' ', max);
    if (corte < max * 0.55) corte = resto.lastIndexOf('.', max);
    if (corte < max * 0.55) corte = resto.lastIndexOf(',', max);
    if (corte < max * 0.55) corte = max;
    out.push(resto.slice(0, corte).trim());
    resto = resto.slice(corte).trim();
  }
  if (resto) out.push(resto);
  return out;
}

/* ───────────────────────── voz (TTS) ───────────────────────── */

async function ttsPiper(texto, voiceCode, rate) {
  const modelo = modeloPiper(voiceCode);
  if (!modelo) return null;
  const args = ['--model', modelo, '--output-raw'];
  const escala = 1 / (Number(rate) || 1);
  if (isFinite(escala) && escala > 0) args.push('--length-scale', escala.toFixed(3));
  return new Promise((ok, ko) => {
    const p = spawn(PIPER, args);
    const out = [], err = [];
    p.stdout.on('data', d => out.push(d));
    p.stderr.on('data', d => err.push(d));
    p.on('error', ko);
    p.on('close', c => c === 0 ? ok(Buffer.concat(out)) : ko(new Error('piper salió con ' + c + ': ' + Buffer.concat(err).toString().slice(0, 300))));
    p.stdin.end(texto);
  });
}

async function ttsEdge(texto, preset, voiceCode) {
  if (!EDGE) return null;
  const { voz, rate, pitch } = vozEdge(preset, voiceCode);
  const tmp = path.join(os.tmpdir(), 'avos-tts-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7) + '.mp3');
  try {
    await new Promise((ok, ko) => {
      const p = spawn(EDGE, ['--voice', voz, '--rate=' + rate, '--pitch=' + pitch,
                             '--text', texto, '--write-media', tmp]);
      const err = [];
      p.stderr.on('data', d => err.push(d));
      p.on('error', ko);
      p.on('close', c => c === 0 ? ok() : ko(new Error('edge-tts salió con ' + c + ': ' + Buffer.concat(err).toString().slice(0, 240))));
    });
    const b = await fsp.readFile(tmp);
    if (!b.length) throw new Error('edge-tts devolvió un archivo vacío');
    return { bytes: b, voz };
  } finally { await fsp.unlink(tmp).catch(() => {}); }
}

async function ttsGoogle(texto) {
  const trozos = trocea(texto, 199);
  const partes = [];
  for (const q of trozos) {
    const url = 'https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=es&q=' + encodeURIComponent(q);
    const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36' } });
    if (!r.ok) throw new Error('Google TTS respondió ' + r.status);
    partes.push(Buffer.from(await r.arrayBuffer()));
  }
  return Buffer.concat(partes);
}

/* ───────────────────── imágenes con IA gratuita ───────────────────── */

const MOTORES = {
  // gratuitos, sin clave de API
  flux:   { nombre: 'Pollinations · flux',   url: p => `https://image.pollinations.ai/prompt/${encodeURIComponent(p)}?model=flux&nologo=true&width=__W__&height=__H__&seed=__S__` },
  turbo:  { nombre: 'Pollinations · turbo',  url: p => `https://image.pollinations.ai/prompt/${encodeURIComponent(p)}?model=turbo&nologo=true&width=__W__&height=__H__&seed=__S__` },
  kontext:{ nombre: 'Pollinations · kontext',url: p => `https://image.pollinations.ai/prompt/${encodeURIComponent(p)}?model=kontext&nologo=true&width=__W__&height=__H__&seed=__S__` },
};

async function generarImagen({ prompt, seed, width, height, motor }) {
  const m = MOTORES[motor] || MOTORES.flux;
  const url = m.url(prompt)
    .replace('__W__', width).replace('__H__', height).replace('__S__', seed);
  const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 AVOS-local' } });
  if (!r.ok) throw new Error(m.nombre + ' respondió ' + r.status);
  return { bytes: Buffer.from(await r.arrayBuffer()), tipo: r.headers.get('content-type') || 'image/jpeg', motor: motor || 'flux', url };
}

/* ───────────────────────── compilar vídeo ───────────────────────── */

const PRESETS = {
  'avos-cinema': ['-c:v', 'libx264', '-crf', '19', '-preset', 'slow', '-pix_fmt', 'yuv420p',
                  '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart'],
  'avos-web':    ['-c:v', 'libx264', '-crf', '24', '-preset', 'veryfast', '-pix_fmt', 'yuv420p',
                  '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart'],
  'avos-master': ['-c:v', 'libx264', '-crf', '16', '-preset', 'veryslow', '-pix_fmt', 'yuv420p',
                  '-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart'],
};

async function compilar(entrada, salidaBase, preset) {
  if (!FFMPEG) return { ffmpeg: false, motivo: 'ffmpeg no está instalado: se guarda el webm tal cual' };
  const args = PRESETS[preset] || PRESETS['avos-cinema'];
  const salida = salidaBase + '.mp4';
  return new Promise(ok => {
    const p = spawn(FFMPEG, ['-y', '-i', entrada, ...args, salida]);
    const err = [];
    p.stderr.on('data', d => err.push(d));
    p.on('error', e => ok({ ffmpeg: false, motivo: String(e.message) }));
    p.on('close', c => {
      if (c === 0 && fs.existsSync(salida)) ok({ ffmpeg: true, preset, ruta: path.relative(RAIZ, salida).split(path.sep).join('/'), bytes: fs.statSync(salida).size });
      else ok({ ffmpeg: false, motivo: 'ffmpeg salió con ' + c + ': ' + Buffer.concat(err).toString().slice(-300) });
    });
  });
}

/* ───────────────────────── rutas ───────────────────────── */

async function api(req, res, url) {
  const p = url.pathname;
  const partes = p.split('/').filter(Boolean);   // ['api', ...]

  /* salud */
  if (p === '/api/salud') {
    return json(res, 200, {
      ok: true,
      tts: {
        piper: !!modeloPiper('es-ES-Standard-A'),
        edge: !!EDGE,
        google: true,
        motor: modeloPiper('es-ES-Standard-A') ? 'piper' : (EDGE ? 'edge-neural' : 'google-no-oficial'),
        voces: Object.entries(VOCES_EDGE).map(([k, v]) => k + '→' + v.voz),
      },
      llm: { qwen_proxy: false, gemini: false },
      imagen: { motores: Object.keys(MOTORES), motor: 'flux' },
      ffmpeg: !!FFMPEG,
      presets: Object.keys(PRESETS),
      almacenamiento: { data: path.relative(RAIZ, DATA) || 'data_local', media: path.relative(RAIZ, MEDIA) || 'media_local' },
    });
  }

  /* voz */
  if (p === '/api/tts' && req.method === 'POST') {
    const b = await leerJSON(req);
    const texto = b.text || b.texto || '';
    if (!texto.trim()) return json(res, 400, { error: 'texto vacío' });
    const rate = b.rate || 1, pitch = b.pitch || 1;
    // 1) Piper local (offline, el que la base espera)
    try {
      const wav = await ttsPiper(texto, b.voiceCode, rate);
      if (wav) { log('tts piper', texto.length, 'chars →', wav.length, 'bytes'); return enviar(res, 200, 'audio/wav', wav); }
    } catch (e) { log('tts piper falló:', e.message); }
    // 2) Edge (voces neuronales, gratis y sin clave)
    if (EDGE) {
      try {
        const r = await ttsEdge(texto, b.voicePreset, b.voiceCode);
        if (r) {
          res.writeHead(200, { 'Content-Type': 'audio/mpeg', 'X-AVOS-Motor': 'edge:' + r.voz, 'Cache-Control': 'no-store' });
          log('tts edge', r.voz, texto.length, 'chars →', r.bytes.length, 'bytes');
          return res.end(r.bytes);
        }
      } catch (e) { log('tts edge falló:', e.message); }
    }
    // 3) Google no oficial
    try {
      const mp3 = await ttsGoogle(texto);
      res.writeHead(200, { 'Content-Type': 'audio/mpeg', 'X-AVOS-Motor': 'google-no-oficial', 'Cache-Control': 'no-store' });
      log('tts google', texto.length, 'chars →', mp3.length, 'bytes');
      return res.end(mp3);
    } catch (e) {
      return json(res, 502, { error: 'sin voz disponible: ' + e.message });
    }
  }

  /* motores de imagen */
  if (p === '/api/motores') {
    return json(res, 200, Object.entries(MOTORES).map(([id, m]) => ({ id, nombre: m.nombre })));
  }

  /* imagen generada */
  if (p === '/api/imagen' && req.method === 'POST') {
    const b = await leerJSON(req);
    const prompt = String(b.prompt || '').trim();
    if (!prompt) return json(res, 400, { error: 'falta el prompt' });
    const seed = Number.isFinite(b.seed) ? b.seed : Math.floor(Math.random() * 1e9);
    const width = Math.min(2048, Number(b.width) || 1024);
    const height = Math.min(2048, Number(b.height) || 576);
    try {
      const r = await generarImagen({ prompt, seed, width, height, motor: b.motor });
      if (b.guardarEn) {
        const nombre = String(b.guardarEn).replace(/[^\w.\-]+/g, '_').slice(0, 90);
        const ext = (r.tipo.split('/')[1] || 'jpg').replace('jpeg', 'jpg');
        const archivo = seguro(path.join(MEDIA, 'escenas'), nombre.includes('.') ? nombre : nombre + '.' + ext);
        await fsp.mkdir(path.dirname(archivo), { recursive: true });
        await fsp.writeFile(archivo, r.bytes);
        log('imagen guardada →', path.relative(RAIZ, archivo));
        return json(res, 200, { ok: true, ruta: '/api/media/escenas/' + path.basename(archivo), bytes: r.bytes.length, motor: r.motor, seed });
      }
      res.writeHead(200, { 'Content-Type': r.tipo, 'X-AVOS-Motor': r.motor, 'Cache-Control': 'no-store' });
      return res.end(r.bytes);
    } catch (e) {
      return json(res, 502, { error: 'el motor de imagen falló: ' + e.message });
    }
  }

  /* compilar */
  if (p === '/api/compilar' && req.method === 'POST') {
    const preset = url.searchParams.get('preset') || 'avos-cinema';
    const nombre = (url.searchParams.get('nombre') || 'video-' + Date.now()).replace(/[^\w.\-]+/g, '_').slice(0, 90);
    const tmp = path.join(MEDIA, 'compilados', nombre + '.webm');
    try {
      const bytes = await volcarA(req, tmp);
      const r = await compilar(tmp, path.join(MEDIA, 'compilados', nombre), preset);
      log('compilar', nombre, bytes, 'bytes →', r.ffmpeg ? r.ruta : r.motivo);
      return json(res, 200, { ok: true, preset, entrante: bytes, rutaWebm: '/api/media/compilados/' + path.basename(tmp), ...r });
    } catch (e) { return json(res, 500, { error: e.message }); }
  }

  /* media: subir */
  if (partes[1] === 'media' && req.method === 'POST') {
    try {
      if (partes[2] === 'video') {
        const nombre = decodeURIComponent(partes[3] || 'video.webm').replace(/[^\w.\-]+/g, '_').slice(0, 90);
        const archivo = seguro(path.join(MEDIA, 'video'), nombre);
        const bytes = await volcarA(req, archivo);
        log('media/video ←', nombre, bytes, 'bytes');
        return json(res, 200, { ok: true, ruta: 'media_local/video/' + path.basename(archivo), bytes });
      }
      if (partes[2] === 'escena') {
        const id = decodeURIComponent(partes[3] || 'escena').replace(/[^\w.\-]+/g, '_').slice(0, 60);
        const n = decodeURIComponent(partes[4] || '0').replace(/[^\w.\-]+/g, '_').slice(0, 10);
        const crudo = (await leerBuffer(req, 200 * 1024 * 1024)).toString('latin1');
        const m = crudo.match(/data:(image\/[a-z+]+);base64,([A-Za-z0-9+/=\s]+)/i);
        if (!m) return json(res, 400, { error: 'no venía una imagen en base64' });
        const ext = (m[1].split('/')[1] || 'png').replace('jpeg', 'jpg');
        const archivo = seguro(path.join(MEDIA, 'escenas'), `${id}-${n}.${ext}`);
        await fsp.mkdir(path.dirname(archivo), { recursive: true });
        await fsp.writeFile(archivo, Buffer.from(m[2].replace(/\s+/g, ''), 'base64'));
        log('media/escena ←', id, n, fs.statSync(archivo).size, 'bytes');
        return json(res, 200, { ok: true, ruta: 'media_local/escenas/' + path.basename(archivo), url: '/api/media/escenas/' + path.basename(archivo) });
      }
      return json(res, 404, { error: 'destino de media no reconocido' });
    } catch (e) { return json(res, 500, { error: e.message }); }
  }

  /* media: leer */
  if (partes[1] === 'media' && req.method === 'GET') {
    try {
      const archivo = seguro(MEDIA, partes.slice(2).join('/'));
      if (!fs.existsSync(archivo)) return json(res, 404, { error: 'no existe' });
      res.writeHead(200, { 'Content-Type': MIME[path.extname(archivo).toLowerCase()] || 'application/octet-stream', 'Content-Length': fs.statSync(archivo).size });
      return fs.createReadStream(archivo).pipe(res);
    } catch (e) { return json(res, 400, { error: e.message }); }
  }

  /* datos: guardar (el cuerpo JSON se vuelca tal cual a disco) */
  if (partes[1] === 'data' && partes[2] === 'save' && req.method === 'POST') {
    try {
      const rel = partes.slice(3).join('/');
      if (!rel) return json(res, 400, { error: 'falta la ruta' });
      const archivo = seguro(DATA, rel + '.json');
      const bytes = await volcarA(req, archivo);
      log('data/save →', rel + '.json', bytes, 'bytes');
      return json(res, 200, { ok: true, ruta: 'data_local/' + rel + '.json', bytes });
    } catch (e) { return json(res, 500, { error: e.message }); }
  }

  /* datos: cargar */
  if (partes[1] === 'data' && partes[2] === 'load') {
    try {
      const rel = partes.slice(3).join('/');
      const archivo = seguro(DATA, rel + '.json');
      if (!fs.existsSync(archivo)) return json(res, 404, { error: 'todavía no hay nada guardado en ' + rel });
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': fs.statSync(archivo).size });
      return fs.createReadStream(archivo).pipe(res);
    } catch (e) { return json(res, 400, { error: e.message }); }
  }

  return json(res, 404, { error: 'endpoint no conocido: ' + p });
}

/* ───────────────────────── estáticos ───────────────────────── */

async function estatico(req, res, url) {
  let rel = decodeURIComponent(url.pathname);
  if (rel === '/') rel = '/index.html';
  let archivo;
  try { archivo = seguro(PUBLIC, rel); } catch { return enviar(res, 403, 'text/plain', 'no permitido'); }
  if (!fs.existsSync(archivo) || fs.statSync(archivo).isDirectory()) {
    if (fs.existsSync(archivo + '.html')) archivo = archivo + '.html';
    else return enviar(res, 404, 'text/plain; charset=utf-8', 'no encontrado: ' + rel);
  }
  const st = fs.statSync(archivo);
  const tipo = MIME[path.extname(archivo).toLowerCase()] || 'application/octet-stream';
  const desde = req.headers.range ? /bytes=(\d*)-(\d*)/.exec(req.headers.range) : null;
  if (desde) {
    const ini = desde[1] ? Number(desde[1]) : 0;
    const fin = desde[2] ? Number(desde[2]) : st.size - 1;
    res.writeHead(206, { 'Content-Type': tipo, 'Content-Range': `bytes ${ini}-${fin}/${st.size}`, 'Accept-Ranges': 'bytes', 'Content-Length': fin - ini + 1 });
    return fs.createReadStream(archivo, { start: ini, end: fin }).pipe(res);
  }
  res.writeHead(200, { 'Content-Type': tipo, 'Content-Length': st.size, 'Accept-Ranges': 'bytes' });
  return fs.createReadStream(archivo).pipe(res);
}

/* ───────────────────────── servidor ───────────────────────── */

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    return await estatico(req, res, url);
  } catch (e) {
    log('ERROR', req.method, url.pathname, e.message);
    if (!res.headersSent) json(res, 500, { error: e.message }); else res.end();
  }
});

server.listen(PUERTO, async () => {
  console.log('');
  console.log('  AVOS · servidor local escuchando en  http://localhost:' + PUERTO);
  console.log('  ────────────────────────────────────────────────────────────');
  console.log('  ffmpeg :', FFMPEG || 'NO instalado → /api/compilar guarda el webm sin recodificar');
  console.log('  piper  :', PIPER || 'NO instalado (voz offline)');
  console.log('  edge   :', EDGE ? 'sí → voces neuronales en español, gratis y sin clave' : 'NO instalado → pip install edge-tts');
  if (!PIPER && !EDGE) console.log('           sin piper ni edge, /api/tts usará el endpoint no oficial de Google');
  console.log('  voces  :', fs.existsSync(VOCES_PIPER) ? fs.readdirSync(VOCES_PIPER).filter(f => f.endsWith('.onnx')).length + ' modelos .onnx en voces/' : 'sin carpeta voces/');
  console.log('  imagen :', Object.keys(MOTORES).join(', '), '(gratis, sin clave)');
  console.log('  datos  : data_local/    media: media_local/');
  console.log('');
});
