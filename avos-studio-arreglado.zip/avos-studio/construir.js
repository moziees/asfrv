#!/usr/bin/env node
/*
 * construir.js — añade los campos que faltan SIN tocar nada de lo que ya existe.
 *
 *   node construir.js
 *
 * Lee:  index.html            (la base, intacta: nunca se escribe encima)
 *       componentes/*.json    (solo campos nuevos, firmados)
 * Escribe: index-completo.html
 *
 * Regla dura: un campo que ya exista en la carta NO se sobrescribe jamás.
 * Solo se añaden claves que faltan. Al final se verifica comparando el AST
 * de los dos archivos: cada campo original debe seguir byte a byte igual.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const acorn = require('acorn');

const RAIZ = __dirname;
const ORIGEN = path.join(RAIZ, 'base', 'index.html');
const SALIDA = path.join(RAIZ, 'public', 'index.html');
const COMP = path.join(RAIZ, 'componentes');

const html = fs.readFileSync(ORIGEN, 'utf8');
const ini = html.indexOf('<script>"use strict"') + '<script>'.length;
const fin = html.lastIndexOf('</script>');
const js = html.slice(ini, fin);

function walk(n, v) {
  if (!n || typeof n !== 'object') return;
  if (Array.isArray(n)) return n.forEach(x => walk(x, v));
  if (n.type) v(n);
  for (const k in n) { if (['type', 'start', 'end', 'loc'].includes(k)) continue; walk(n[k], v); }
}
const ast = acorn.parse(js, { ecmaVersion: 'latest' });

// mapa: id de mazo → { number de carta → nodo ObjectExpression }
let na = null;
walk(ast, n => { if (n.type === 'VariableDeclarator' && n.id.name === 'na' && n.init) na = n.init; });
if (!na) throw new Error('no encuentro el registro de mazos (na)');

const mazos = {};
na.elements.forEach(d => {
  const p = {};
  d.properties.forEach(q => { if (q.type === 'Property') p[q.key.name || q.key.value] = q.value; });
  const id = p.id && p.id.value;
  mazos[id] = {};
  (p.cartas.elements || []).forEach(c => {
    if (c.type !== 'ObjectExpression') return;
    const np = c.properties.find(q => q.type === 'Property' && (q.key.name || q.key.value) === 'number');
    if (np && np.value.type === 'Literal') mazos[id][String(np.value.value)] = c;
  });
});

// qué claves tiene ya cada carta
const clavesDe = nodo => new Set(nodo.properties.filter(p => p.type === 'Property').map(p => p.key.name || p.key.value));

const lit = s => JSON.stringify(s).replace(/</g, '\\u003c');
const inserciones = [];
const reemplazos = [];
let renombradas = 0;
const resumen = { cartas: 0, campos: 0, saltados: 0, noEncontradas: [] };

fs.readdirSync(COMP).filter(f => f.endsWith('.json')).sort().forEach(f => {
  const d = JSON.parse(fs.readFileSync(path.join(COMP, f), 'utf8'));
  const idMazo = d._mazo;
  if (!mazos[idMazo]) { console.log('  ⚠ ' + f + ': el mazo "' + idMazo + '" no existe en la base'); return; }
  // archivo de renombrado: es el ÚNICO caso en que se sobrescribe un campo tuyo,
  // y solo si el archivo está en componentes/ (no en componentes/apartados/)
  if (d._renombrar) {
    let r = 0;
    d.cartas.forEach(c => {
      const nodo = mazos[idMazo][String(c.number)];
      if (!nodo) { resumen.noEncontradas.push(idMazo + ':' + c.number); return; }
      const pr = nodo.properties.find(q => q.type === 'Property' && (q.key.name || q.key.value) === 'title');
      if (!pr) return;
      reemplazos.push({ start: pr.value.start, end: pr.value.end, texto: lit(c.title) });
      if (d.guardar_title_original && c.title_original)
        inserciones.push({ pos: nodo.end - 1, texto: ',titleOriginal:' + lit(c.title_original) });
      r++; renombradas++;
    });
    console.log('  · ' + f.padEnd(26) + r + ' títulos renombrados (originales guardados en titleOriginal)');
    return;
  }
  let n = 0;
  d.cartas.forEach(c => {
    const nodo = mazos[idMazo][String(c.number)];
    if (!nodo) { resumen.noEncontradas.push(idMazo + ':' + c.number); return; }
    const ya = clavesDe(nodo);
    const trozos = [];
    ['explicacion', 'demanda', 'mantra', 'ritual', 'firma'].forEach(k => {
      if (c[k] === undefined) return;
      if (ya.has(k)) { resumen.saltados++; return; }          // ← NUNCA se sobrescribe
      trozos.push(k + ':' + lit(c[k]));
    });
    if (c.preguntas && !ya.has('preguntas')) trozos.push('preguntas:' + lit(c.preguntas).replace(/</g, '\\u003c'));
    else if (c.preguntas) resumen.saltados++;
    if (!trozos.length) return;
    // insertar justo antes de la llave de cierre del objeto-carta
    inserciones.push({ pos: nodo.end - 1, texto: ',' + trozos.join(',') });
    resumen.cartas++; resumen.campos += trozos.length; n++;
  });
  console.log('  · ' + f.padEnd(26) + n + ' cartas, mazo "' + idMazo + '"');
});

if (resumen.noEncontradas.length) console.log('  ⚠ no encontradas en la base: ' + resumen.noEncontradas.join(', '));

// aplicar de atrás adelante para no descolocar las posiciones
const ops = [...inserciones.map(i => ({ tipo: 'ins', at: i.pos, ...i })),
             ...reemplazos.map(r => ({ tipo: 'rep', at: r.start, ...r }))];
ops.sort((a, b) => b.at - a.at);
let jsNuevo = js;
ops.forEach(o => {
  jsNuevo = o.tipo === 'ins'
    ? jsNuevo.slice(0, o.pos) + o.texto + jsNuevo.slice(o.pos)
    : jsNuevo.slice(0, o.start) + o.texto + jsNuevo.slice(o.end);
});

const htmlNuevo = html.slice(0, ini) + jsNuevo + html.slice(fin);
fs.writeFileSync(SALIDA, htmlNuevo);

console.log('\n── resultado ──');
console.log('  cartas tocadas          :', resumen.cartas);
console.log('  campos AÑADIDOS         :', resumen.campos);
console.log('  títulos RENOMBRADOS     :', renombradas, renombradas ? '(los originales quedan en titleOriginal)' : '');
console.log('  campos YA EXISTÍAN (no se tocan):', resumen.saltados);
console.log('  base/index.html         :', fs.statSync(ORIGEN).size.toLocaleString('es'), 'bytes (sin escribir)');
console.log('  public/index.html       :', fs.statSync(SALIDA).size.toLocaleString('es'), 'bytes');
console.log('  crecimiento             : +' + (fs.statSync(SALIDA).size - fs.statSync(ORIGEN).size).toLocaleString('es') + ' bytes');
