#!/usr/bin/env bash
# AVOS Studio · comprueba el entorno y arranca.
#   ./arrancar.sh              → http://localhost:8080
#   PUERTO=9000 ./arrancar.sh
set -euo pipefail
cd "$(dirname "$0")"
PUERTO="${PUERTO:-8080}"
echo "── AVOS Studio · comprobación ──"

if command -v node >/dev/null 2>&1; then
  V="$(node -v | tr -d v | cut -d. -f1)"
  [ "$V" -ge 18 ] && echo "  ✅ node $(node -v)" || { echo "  ❌ node $(node -v) — hace falta 18+"; exit 1; }
else
  echo "  ❌ node no instalado:"
  echo "     Debian/Ubuntu/Mint  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs"
  echo "     Fedora              sudo dnf install -y nodejs"
  echo "     Arch                sudo pacman -S --needed nodejs npm"
  echo "     sin root            curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash && nvm install 20"
  exit 1
fi

command -v ffmpeg >/dev/null 2>&1 \
  && echo "  ✅ ffmpeg $(ffmpeg -version 2>/dev/null | head -1 | cut -d' ' -f3) → mp4 real en /api/compilar" \
  || echo "  ⚠ ffmpeg no instalado → el vídeo saldrá webm (YouTube también lo acepta)
       sudo apt install -y ffmpeg"

if command -v edge-tts >/dev/null 2>&1; then
  echo "  ✅ edge-tts $(edge-tts --version 2>/dev/null | head -1 | cut -d' ' -f2) → voces neuronales en español, gratis y sin clave"
elif [ -x piper/piper ] && ls voces/*.onnx >/dev/null 2>&1; then
  echo "  ✅ piper + $(ls voces/*.onnx | wc -l) voz(es) → locución offline"
else
  echo "  ⚠ sin motor de voz bueno → se usará el endpoint no oficial de Google
       voces neuronales:  pip install edge-tts        (o pipx install edge-tts)
       voz offline:      ./instalar_voz.sh"
fi

[ -f base/index.html ] && echo "  ✅ base/index.html intacta ($(du -h base/index.html | cut -f1))" || { echo "  ❌ falta base/index.html"; exit 1; }
[ -f public/index.html ] && echo "  ✅ public/index.html construida ($(ls componentes/*.json 2>/dev/null | wc -l) componentes aplicados)" || { echo "  · public/index.html no existe todavía: node construir.js"; }

echo
echo "── arrancando en http://localhost:$PUERTO ──"
echo "    /            la app          /todo.html     índice de todo"
echo "    /imagenes.html  generador de imágenes para las escenas"
echo
PORT="$PUERTO" exec node servidor.js
