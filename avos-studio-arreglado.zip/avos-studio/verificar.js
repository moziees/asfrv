#!/usr/bin/env node
/*
 * verificar.js — demuestra que index-completo.html es index.html + campos nuevos,
 * y nada más. Tres pruebas:
 *   1. todo lo que NO es una carta es byte a byte idéntico en los dos archivos
 *   2. en cada carta, todos los campos originales siguen con el mismo valor
 *   3. las únicas claves nuevas son las firmadas como qwen-completado
 *   4. la app arranca sin errores
 */
'use strict';
const fs = require('fs');
const path = require('path');
const acorn = require('acorn');

function bundle(f) {
  const h = fs.readFileSync(f, 'utf8');
  const i = h.indexOf('<script>"use strict"') + '<script>'.length;
  const j = h.lastIndexOf('</script>');
  return { html: h, js: h.slice(i, j), pre: h.slice(0, i), post: h.slice(j) };
}
function walk(n, v) {
  if (!n || typeof n !== 'object') return;
  if (Array.isArray(n)) return n.forEach(x => walk(x, v));
  if (n.type) v(n);
  for (const k in n) { if (['type', 'start', 'end', 'loc'].includes(k)) continue; walk(n[k], v); }
}
const lit = x => {
  if (!x) return undefined;
  if (x.type === 'Literal') return x.value;
  if (x.type === 'TemplateLiteral') return x.quasis.map(q => q.value.cooked).join('\u0000');
  if (x.type === 'UnaryExpression') {
    const a = lit(x.argument);
    if (x.operator === '!' && typeof a === 'boolean') return !a;
    if (x.operator === '-' && typeof a === 'number') return -a;
    if (x.operator === 'void') return undefined;
    return x.operator + '(' + JSON.stringify(a) + ')';
  }
  if (x.type === 'ArrayExpression') return x.elements.map(lit);
  if (x.type === 'ObjectExpression') return Object.fromEntries(x.properties.filter(p => p.type === 'Property').map(p => [p.key.name || p.key.value, lit(p.value)]));
  // cualquier otra cosa: se compara por su TEXTO fuente, no por su posición
  return JS_ACTUAL.slice(x.start, x.end);
};

let JS_ACTUAL = '';
function cartasDe(archivo) {
  const b = bundle(archivo); JS_ACTUAL = b.js;
  const ast = acorn.parse(b.js, { ecmaVersion: 'latest' });
  const out = new Map();
  walk(ast, n => {
    if (n.type !== 'ObjectExpression') return;
    const p = {};
    n.properties.forEach(q => { if (q.type === 'Property') p[q.key.name || q.key.value] = q.value; });
    if (p.number && p.title && p.number.type === 'Literal') {
      // clave SIN el título: si se renombra, la carta debe seguir siendo la misma
      const clave = (p.type ? p.type.value + '|' : '') + p.number.value;
      out.set(clave, { rango: [n.start, n.end], campos: Object.fromEntries(Object.entries(p).map(([k, v]) => [k, lit(v)])) });
    }
  });
  return { b, out };
}

const A = cartasDe(path.join(__dirname, 'base', 'index.html'));
const B = cartasDe(path.join(__dirname, 'public', 'index.html'));

// ── prueba 1: todo lo que no es carta, idéntico ──
function sinCartas(x) {
  const js = x.b.js;
  const rangos = [...x.out.values()].map(c => c.rango).sort((a, b) => a[0] - b[0]);
  let s = '', k = 0;
  rangos.forEach(([i, j], n) => { s += js.slice(k, i) + '⟦' + n + '⟧'; k = j; });
  return x.b.pre + s + js.slice(k) + x.b.post;
}
const sa = sinCartas(A), sb = sinCartas(B);
console.log('1 · todo lo que NO es una carta:');
console.log('    idéntico byte a byte  :', sa === sb ? '✅ SÍ (' + sa.length.toLocaleString('es') + ' bytes)' : '❌ NO');
if (sa !== sb) { let i = 0; while (sa[i] === sb[i]) i++; console.log('    primera diferencia en', i, JSON.stringify(sa.slice(i - 60, i + 60)), 'VS', JSON.stringify(sb.slice(i - 60, i + 60))); }

// ── pruebas 2 y 3: campo a campo ──
let iguales = 0, cambiados = [], nuevas = new Set(), borradas = [], renombradosOk = 0;
// si hay un archivo de renombrado activo, se permite que cambie `title`
// siempre que el original quede guardado en `titleOriginal`
const fs0 = require('fs');
const ren = fs0.readdirSync(path.join(__dirname, 'componentes')).filter(f => f.endsWith('.json'))
  .map(f => JSON.parse(fs0.readFileSync(path.join(__dirname, 'componentes', f), 'utf8')))
  .filter(d => d._renombrar);
const renombrados = new Map();
ren.forEach(d => d.cartas.forEach(c => renombrados.set(d._mazo + '|' + c.number, c)));
const nuevasEsperadas = new Set(['explicacion', 'demanda', 'preguntas', 'mantra', 'ritual', 'firma', 'titleOriginal']);
A.out.forEach((ca, clave) => {
  const cb = B.out.get(clave);
  if (!cb) { borradas.push(clave); return; }
  for (const k in ca.campos) {
    if (!(k in cb.campos)) { borradas.push(clave + '.' + k); continue; }
    if (JSON.stringify(ca.campos[k]) === JSON.stringify(cb.campos[k])) { iguales++; continue; }
    // único cambio consentido: un título renombrado cuyo original queda guardado
    if (k === 'title' && cb.campos.titleOriginal !== undefined && cb.campos.titleOriginal === ca.campos.title) { renombradosOk++; continue; }
    cambiados.push(clave + '.' + k);
  }
  for (const k in cb.campos) if (!(k in ca.campos)) nuevas.add(k);
});
console.log('\n2 · campos originales de las cartas:');
console.log('    sin alterar            :', iguales);
console.log('    cambiados              :', cambiados.length ? '❌ ' + cambiados.length + ' → ' + cambiados.slice(0, 5).join(', ') : '✅ 0');
console.log('    títulos renombrados con el original guardado en titleOriginal:', renombradosOk);
console.log('    borrados               :', borradas.length ? '❌ ' + borradas.slice(0, 5).join(', ') : '✅ 0');
console.log('    cartas en cada archivo :', A.out.size, '/', B.out.size, A.out.size === B.out.size ? '✅' : '❌');

console.log('\n3 · claves nuevas aparecidas:');
console.log('    ', [...nuevas].join(', ') || '(ninguna)');
const intrusas = [...nuevas].filter(k => !nuevasEsperadas.has(k));
console.log('    fuera de lo esperado   :', intrusas.length ? '❌ ' + intrusas.join(', ') : '✅ ninguna');

const firmadas = [...B.out.values()].filter(c => c.campos.firma === 'qwen-completado').length;
console.log('    cartas con firma qwen-completado:', firmadas);

// ── prueba 4: parsea ──
try { acorn.parse(B.b.js, { ecmaVersion: 'latest' }); console.log('\n4 · el bundle completo parsea  : ✅'); }
catch (e) { console.log('\n4 · el bundle completo parsea  : ❌', e.message); }

const ok = sa === sb && !cambiados.length && !borradas.length && !intrusas.length && A.out.size === B.out.size;
console.log('\n' + (ok ? '✅ VEREDICTO: public/index.html = base/index.html + campos nuevos. Nada sustituido, nada cambiado, nada borrado.'
                     : '❌ VEREDICTO: hay diferencias que no deberían estar.'));
process.exit(ok ? 0 : 1);
